 <div class="col-sm-6">
     <?
  if($campo==""){
    $sql="SELECT nombre,tema,codigo,procedencia,caratula FROM tbllibro";
  }else{
    $sql="SELECT nombre,tema,codigo,procedencia,caratula FROM tbllibro where nombre like '$campo%'";
  }

include 'confing/conexion.php';
  $registro=mysqli_query($con,$sql) or die('Error en sql');
  echo '<table><tr><td>codigo</td><td>nombre</td><td></td></tr>';
  while($r=mysqli_fetch_array($registro)){
    echo "<tr><td>".$r['codigo']."</td><td>".$r['nombre']."</td>
   <td><img src=img/".$r['caratula']."></td>
     </tr>";
  }
?>
</table>
  </div>