<?
$host="b9feb7ugvpkagape9up1-mysql.services.clever-cloud.com";
$bd="b9feb7ugvpkagape9up1";
$user="ufpxcsd2ig2p4qob";
$pwd="12ysjtvIYkg4dTRYanS3";
$con=mysqli_connect($host,$user,$pwd,$bd) or
    die(" Problemas en la conexión");
?>
