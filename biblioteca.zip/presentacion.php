<div class="jumbotron text-center">
  <h1>Biblioteca</h1>
 <p>
<img src="img/si.png">
 </p>
</div>